package com.example.clase27_4

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class pantallaDeLogin : Fragment() {

    companion object {
        fun newInstance() = pantallaDeLogin()
    }

    private lateinit var viewModel: PantallaDeLoginViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_pantalla_de_login, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(PantallaDeLoginViewModel::class.java)
        // TODO: Use the ViewModel
    }

}