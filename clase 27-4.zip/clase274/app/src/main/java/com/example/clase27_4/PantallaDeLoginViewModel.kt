package com.example.clase27_4

import androidx.lifecycle.ViewModel

class PantallaDeLoginViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}