package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.google.android.material.snackbar.Snackbar

class Cliente(usuario: String, clave: String)
{
    var usuario = usuario
    var clave = clave

}

class MainActivity : AppCompatActivity() {

    lateinit var botonLogin: Button
    lateinit var textoUsuario: EditText
    lateinit var textoClave: EditText
    lateinit var botonCrear: Button

    var listaClientes: MutableList <Cliente> = mutableListOf(Cliente("a", "a"), Cliente("b", "b"))
    var flag: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        botonLogin = findViewById(R.id.botonLogin)
        textoUsuario = findViewById(R.id.campoUsuario)
        textoClave = findViewById(R.id.campoClave)
        botonCrear = findViewById(R.id.botonCrear)

        botonLogin.setOnClickListener()
        {
            flag = 0

            for(i in listaClientes)
            {
                if(textoUsuario.text.toString() == i.usuario && textoClave.text.toString() == i.clave)
                {
                    flag = 1
                }
            }

            if(flag == 0)
            {
                var snackbar = Snackbar.make(it,"Usuario y contraseña incorrectos", Snackbar.LENGTH_SHORT)
                snackbar.show()
            }else
            {
                var snackbar = Snackbar.make(it,"Bienvenido", Snackbar.LENGTH_SHORT)
                snackbar.show()
            }


        }

        botonCrear.setOnClickListener()
        {
            var snackbar = Snackbar.make(it,"Ingrese un nombre de usuario y clave. Luego presione confirmar", Snackbar.LENGTH_SHORT)
            snackbar.show()
            botonCrear.text = "Confirmar"
            botonCrear.setOnClickListener()
            {

                for(i in listaClientes)
                {
                    if(textoUsuario.text.toString() == i.usuario)
                    {
                        flag = 1
                    }
                }

                if (flag == 0)
                {
                    listaClientes.add(Cliente(textoUsuario.text.toString(), textoClave.text.toString()))
                    var snackbar = Snackbar.make(it,"Usuario creado", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                    botonCrear.text = "Crear usuario"
                }else
                {
                    flag = 0
                    var snackbar = Snackbar.make(it,"Usuario ya existe", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                    botonCrear.text = "Crear usuario"
                }

            }
        }

    }
}
